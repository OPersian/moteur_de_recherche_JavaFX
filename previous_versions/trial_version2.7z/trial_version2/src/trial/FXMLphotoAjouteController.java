package trial;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author Olena
 */
public class FXMLphotoAjouteController implements Initializable, MainScreen {
    
    ÉcranContrôleur myController;
    
    public void setScreenParent(ÉcranContrôleur screenParent){ 
        myController = screenParent; 
    } 
     
    @FXML 
    private void allerPhotoAjoute(ActionEvent event){ 
        myController.setScreen(ÉcranFramework.PHOTO_AJOUTE); 
    }     
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void allerArticleAjoute(ActionEvent event) {
        myController.setScreen(ÉcranFramework.ARTICLE_AJOUTE);
    }
    
}
