package trial;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Persianova, Golubnycha
 */

public class ÉcranFramework extends Application {
    
    /*String nom;
    String corps;*/ //trial; by OPersian
    
    //public static final String PAGE_ACCUEIL = "PageAccueilController"; 
    //public static final String PAGE_ACCUEIL_FXML = "PageAccueilFXML.fxml";
    
    public static final String PHOTO_AJOUTE = "FXMLphotoAjouteController"; 
    public static final String PHOTO_AJOUTE_FXML = "FXMLphotoAjoute.fxml"; 
    
    public static final String ARTICLE_AJOUTE = "FXMLarticleAjouteController"; 
    public static final String ARTICLE_AJOUTE_FXML = "FXMLarticleAjoute.fxml"; 
    
    @Override
    public void start(Stage stage) throws Exception {
        
        ÉcranContrôleur mainContainer = new ÉcranContrôleur();
        mainContainer.loadScreen(ÉcranFramework.PHOTO_AJOUTE, 
                            ÉcranFramework.PHOTO_AJOUTE_FXML);        
        mainContainer.loadScreen(ÉcranFramework.ARTICLE_AJOUTE, 
                            ÉcranFramework.ARTICLE_AJOUTE_FXML);
        
        //mainContainer.setScreen(ÉcranFramework.PAGE_ACCUEIL);
        mainContainer.setScreen(ÉcranFramework.ARTICLE_AJOUTE);
        
        
        //http://docs.oracle.com/javafx/2/fxml_get_started/fxml_tutorial_intermediate.htm#CACHBAEJ 
        stage.setTitle("MotsApp Application");
        
        //Parent root = FXMLLoader.load(getClass().getResource("FXMLarticleAjoute.fxml"));
        Group root = new Group();
        root.getChildren().addAll(mainContainer);
        Scene scene = new Scene(root);        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
        
        /*java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            new Image().setVisible(true);
            }
        });*/
    }
    
}
