package trial.contrôleurs;

import trial.contrôleurs.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TitledPane;

/**
 * FXML Controller class
 *
 * @author Persianova, Golubnycha
 */
public class PageAccueilController implements Initializable {   
 
    
    @FXML private TitledPane x1;
    @FXML private TitledPane x2;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
