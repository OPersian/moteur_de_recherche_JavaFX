package trial;

import java.net.URL;
import java.time.LocalDate;

/**
 *
 * @author Persianova, Golubnycha
 */
    
public abstract class Matière implements Comparable {

private String titre;
private LocalDate date;
private String auteur;
private URL source;  
    
public Matière(String titre, String auteur, 
               LocalDate date, URL source)
    {      
        this.titre = titre;
        this.date = date;
        this.auteur = auteur;
        this.source = source;            
    }
    
@Override
public String toString()
{         
    String s = ("Titre: " + titre + "\n" + "Auteur: " + auteur
            + "\n" + "Date:" + date + "\n" + "Lien:" + source.getAuthority());
    return s;
}        
    
@Override 
public int compareTo(Object o)
{
    Matière n = (Matière)o;
    return this.titre.compareTo(n.titre);
}
    
public void set_titre(String titre){this.titre = titre;}    
public String get_titre(){return this.titre;}        
    
public void set_date(LocalDate date){this.date = date;}    
public LocalDate get_datee(){return this.date;}      
    
public void set_auteur(String auteur){this.auteur = auteur;}    
public String get_auteur(){return this.auteur;}      
    
public void set_source(URL source){this.source = source;}    
public URL get_source(){return this.source;}   

}
    
    
    


