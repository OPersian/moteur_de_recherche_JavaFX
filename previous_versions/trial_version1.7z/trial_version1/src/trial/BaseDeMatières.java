package trial;

import java.util.Iterator;
import java.util.TreeSet;

/**
 *
 * @author Persianova, Golubnycha
 */

public class BaseDeMatières {
    
    private TreeSet<Matière> mabase;
    //TreeSet news_item;
    public BaseDeMatières()
    {
        mabase = new TreeSet<Matière>();
    }
    
    public void ajouterMatière(Matière n)
    {
        mabase.add(n);
    }
    
    public void baseAfficher(){
        
        Iterator it = mabase.iterator();
        while (it.hasNext())
        {
            System.out.println(it.next());
        }
    }
    
}
