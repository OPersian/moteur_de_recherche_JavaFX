package trial;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 *
 * @author Persianova, Golubnycha
 */

public class FXMLDocumentController implements Initializable {
    
    private Label label;
    private TextField textField1;
    private TextArea textArea1;
    @FXML
    private Button save_btn;
    @FXML
    private TextField textFieldTitre;
    @FXML
    private TextArea textAreaContenu;
    @FXML
    private TextField textFieldDate;
    @FXML
    private TextField textFieldAuteur;
    @FXML
    private TextField textFieldSource;
    @FXML
    private Label successMsgLabel;
    
    private void handleButtonAction(ActionEvent event) { //default
        /*System.out.println("You clicked me!"); //by OPersian
        label.setText("Hello World!");*/
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // create a new Matiere????
    }    

    private void new_method(ActionEvent event) { //trial; by OPersian
        /*Trial trial = new Trial();
        trial.nom = "ddd";        
        trial.nom = textField1.getText();  
        trial.corps = textArea1.getText();  
        System.out.println(trial.nom);
        System.out.println(trial.corps); */
    }

    @FXML
    private void textField1_action(ActionEvent event) {
    }

    @FXML
    private void sauvegarder(ActionEvent event) throws MalformedURLException {
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-"
                + "MM-yyyy");    
        LocalDate date = LocalDate.now();
        String date_format = textFieldDate.getText();
        try {
            date = LocalDate.parse(date_format, formatter);
        } 
        catch (DateTimeParseException e) {
            System.out.println("Date format est incorrect!");
        }  
        
        String monurl = textFieldSource.getText();   
        URL source = new URL(monurl);        
        try {
            source = new URL(monurl);
        }
        catch (MalformedURLException e) {
            System.out.println("URL format incorrect!");
            successMsgLabel.setText("On ne peut pas enregistrer vos donnés!");
        }           
        
        Article monArticle = new Article(
                textFieldTitre.getText(),
                textFieldAuteur.getText(),
                date,
                source, 
                textAreaContenu.getText(),
                true
        );
        //System.out.println(monArticle.get_titre());
        //System.out.println(monArticle);
        
        BaseDeMatières mabase = new BaseDeMatières();
        mabase.ajouterMatière(monArticle);
        mabase.baseAfficher();
        
        try {successMsgLabel.setText("L'article a été bien sauvegardé!");}
        catch (Exception e) {
            successMsgLabel.setText("On ne peut pas enregistrer vos donnés!");
        }       

    }
    
}
