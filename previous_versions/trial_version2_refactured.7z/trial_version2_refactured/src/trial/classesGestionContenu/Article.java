package trial.classesGestionContenu;

import java.net.URL;
import java.time.LocalDate;

/**
 *
 * @author Persianova, Golubnycha
 */

public class Article extends Matière {

    private String contenu;
    private boolean version; //0 - en version electronique seulement,
                          //1 - en versions electronique et en papier  

    public Article(String titre, 
                   String auteur, 
                   LocalDate date, 
                   URL source,
                   String contenu,
                   boolean version) 
    {
        super(titre, auteur, date, source);
        
        this.contenu = contenu;
        this.version = version;         
    }
    
    @Override
    public String toString()
    {  
        String message;
        if (this.version) message = "electronique et en papier";
        else  message = "electronique";
        
        String s = ("\n" + "Contenu: " + this.get_contenu() + "\n" +
                    "Version: " + message);
        //return s;         
        return super.toString() + s; 
    }
  
    public void set_contenu(String contenu)
        {this.contenu = contenu;}    
    public String get_contenu(){return this.contenu;}    
    
}
