package trial.contrôleurs;

import trial.classesGestionContenu.BaseDeMatières;
import trial.classesGestionContenu.Article;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import trial.MainScreen;
import trial.ÉcranContrôleur;
import trial.ÉcranFramework;

/**
 * FXML Controller class
 *
 * @author Persianova, Golubnycha
 */
public class ArticleAjouteContrôleur implements Initializable, MainScreen {    
    
    ÉcranContrôleur myController;
    @FXML
    private Menu menuItemAider;
    @FXML
    private Button rechercherBtn;
    
    @Override
    public void setScreenParent(ÉcranContrôleur screenParent){ 
        myController = screenParent; 
    } 
         
    @FXML
    private MenuItem menuItemPageAccueil;
    @FXML
    private MenuItem menuItemArticleAjoute;
    @FXML
    private MenuItem menuItemPhotoAjoute;
    @FXML
    private MenuItem menuItemOuvrir;
    @FXML
    private MenuItem menuItemSauvegarder;
    @FXML
    private MenuItem menuItemSupprimer;
    @FXML
    private Menu menuItemModifier;
    @FXML
    private Menu menuItemIndexer;
    @FXML
    private TextField textFieldRechercher;
     
    @FXML
    private Button save_btn;
    @FXML
    private TextField textFieldTitre;
    @FXML
    private TextArea textAreaContenu;
    @FXML
    private TextField textFieldDate;
    @FXML
    private TextField textFieldAuteur;
    @FXML
    private TextField textFieldSource;
    @FXML
    private Label successMsgLabel;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void sauvegarder(ActionEvent event) throws MalformedURLException {
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-"
                + "MM-yyyy");    
        LocalDate date = LocalDate.now();
        String date_format = textFieldDate.getText();
        try {
            date = LocalDate.parse(date_format, formatter);
        } 
        catch (DateTimeParseException e) {
            System.out.println("Date format est incorrect!");
        }  
        
        String monurl = textFieldSource.getText();   
        //URL source = new URL(monurl); 
        URL source = new URL("http://sample.com.ua");                
        try {
            source = new URL(monurl);
        }
        catch (MalformedURLException e) {
            System.out.println("URL format incorrect!");
            successMsgLabel.setText("On ne peut pas enregistrer vos donnés!");
        }           
        
        Article monArticle = new Article(
                textFieldTitre.getText(),
                textFieldAuteur.getText(),
                date,
                source, 
                textAreaContenu.getText(),
                true
        );
        //System.out.println(monArticle.get_titre());
        //System.out.println(monArticle);
        
        BaseDeMatières mabase = new BaseDeMatières();
        mabase.ajouterMatière(monArticle);
        mabase.baseAfficher();
        
        try {successMsgLabel.setText("L'article a été bien sauvegardé!");}
        catch (Exception e) {
            successMsgLabel.setText("On ne peut pas enregistrer vos donnés!");
        }       

    }
        

    @FXML
    private void textField1_action(ActionEvent event) {
    }

    @FXML
    private void rechercher(ActionEvent event) {
    }

    @FXML
    private void allerPhotoAjoute(ActionEvent event) {
        myController.setScreen(ÉcranFramework.PHOTO_AJOUTE);   

    }
    

    @FXML
    private void allerArticleAjoute(ActionEvent event) {
        myController.setScreen(ÉcranFramework.ARTICLE_AJOUTE);       
    }

    
}
