package trial.contrôleurs;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import trial.MainScreen;
import trial.ÉcranContrôleur;
import trial.ÉcranFramework;

/**
 * FXML Controller class
 *
 * @author Olena
 */
public class PhotoAjouteContrôleur implements Initializable, MainScreen {
    
    ÉcranContrôleur myController;
    
    @Override
    public void setScreenParent(ÉcranContrôleur screenParent){ 
        myController = screenParent; 
    } 
     
    @FXML 
    private void allerPhotoAjoute(ActionEvent event){ 
        myController.setScreen(ÉcranFramework.PHOTO_AJOUTE); 
    }     
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void allerArticleAjoute(ActionEvent event) {
        myController.setScreen(ÉcranFramework.ARTICLE_AJOUTE);
    }

    @FXML
    private void uploadPhoto(ActionEvent event) {
        
        
    }
    
}
