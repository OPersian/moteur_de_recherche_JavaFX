package trial;

/**
 *
 * @author Persianova, Golubnycha
 */
public interface MainScreen {
    
    //This method will allow the injection of the Parent ScreenPane 
     public void setScreenParent(ÉcranContrôleur screenPage);     
}
