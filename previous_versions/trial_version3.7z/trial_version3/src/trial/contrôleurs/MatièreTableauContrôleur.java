/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trial.contrôleurs;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import trial.InterfaceMainScreen;
import trial.ÉcranManager;

/**
 * FXML Controller class
 *
 * @author Olena
 */
public class MatièreTableauContrôleur implements Initializable, 
                                                 InterfaceMainScreen {
    ÉcranManager myController;
    
    @FXML
    private TableView<?> matièreTableauVue;
    @FXML
    private TableColumn<?, ?> matièreTitre;
    @FXML
    private TableColumn<?, ?> matièreAuteur;
    @FXML
    private TableColumn<?, ?> matièreDate;
    @FXML
    private TableColumn<?, ?> matièreSource;
    
    @Override
    public void setScreenParent(ÉcranManager screenParent){ 
        myController = screenParent; 
    } 
    


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
