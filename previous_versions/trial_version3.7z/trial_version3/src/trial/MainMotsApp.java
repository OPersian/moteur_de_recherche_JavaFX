package trial;

import javafx.application.Application;
//import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
//import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
//import trial.contrôleurs.*;
//import trial.classesGestionContenu.*;

/**
 *
 * @author Persianova, Golubnycha
 */

public class MainMotsApp extends Application {
    
    //public static final String PAGE_ACCUEIL = "PageAccueilController"; 
    //public static final String PAGE_ACCUEIL_FXML = "PageAccueilFXML.fxml";
        
    //http://stackoverflow.com/questions/19602727/how-to-reference-javafx-fxml-files-in-resource-folder
    public static final String PHOTO_AJOUTE = "/trial/contrôleurs/PhotoAjouteController"; 
    public static final String PHOTO_AJOUTE_FXML = "/trial/fichiersFxml/PhotoAjoute.fxml"; 
    
    public static final String ARTICLE_AJOUTE = "/trial/contrôleurs/ArticleAjouteController"; 
    public static final String ARTICLE_AJOUTE_FXML = "/trial/fichiersFxml/ArticleAjoute.fxml"; 
    
    public static final String MATIÉRE_TABLEAU = "/trial/contrôleurs/MatièreTableContrôleur"; 
    public static final String MATIÉRE_TABLEAU_FXML = "/trial/fichiersFxml/MatièreTable.fxml"; 
    
    @Override
    public void start(Stage stage) throws Exception {
        
        ÉcranManager mainContainer = new ÉcranManager();
        mainContainer.loadScreen(MainMotsApp.PHOTO_AJOUTE, 
                            MainMotsApp.PHOTO_AJOUTE_FXML);        
        mainContainer.loadScreen(MainMotsApp.ARTICLE_AJOUTE, 
                            MainMotsApp.ARTICLE_AJOUTE_FXML);        
        mainContainer.loadScreen(MainMotsApp.MATIÉRE_TABLEAU, 
                            MainMotsApp.MATIÉRE_TABLEAU_FXML);        
        
        //mainContainer.setScreen(MainMotsApp.PAGE_ACCUEIL);
        mainContainer.setScreen(MainMotsApp.ARTICLE_AJOUTE);
        
        
        //http://docs.oracle.com/javafx/2/fxml_get_started/fxml_tutorial_intermediate.htm#CACHBAEJ 
        stage.setTitle("MotsApp Application");
        
        //Parent root = FXMLLoader.load(getClass().getResource("FXMLarticleAjoute.fxml"));
        Group root = new Group();
        root.getChildren().addAll(mainContainer);
        Scene scene = new Scene(root);        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
        
        /*java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            new Image().setVisible(true);
            }
        });*/
    }
    
}
