package trial;

/**
 *
 * @author Persianova, Golubnycha
 */
public interface InterfaceMainScreen {
    
    //This method will allow the injection of the Parent ScreenPane 
     public void setScreenParent(ÉcranManager screenPage);     
}
