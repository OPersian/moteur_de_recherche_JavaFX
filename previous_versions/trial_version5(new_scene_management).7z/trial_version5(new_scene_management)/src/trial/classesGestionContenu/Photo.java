package trial.classesGestionContenu;

/**
 *
 * @author Persianova, Golubnycha
 */
public class Photo {
    
}
