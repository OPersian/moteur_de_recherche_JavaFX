package trial;

import trial.contrôleurs.RootLayoutContrôleur;
import java.io.IOException;
import java.io.InputStream;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.JavaFXBuilderFactory;
//import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
//import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import trial.classesGestionContenu.Article;
//import trial.contrôleurs.*;
//import trial.classesGestionContenu.*;

/**
 *
 * @author Persianova, Golubnycha
 */

public class MainMotsApp extends Application {
    
    /*--------------------------gestion des scenes----------------------------*/    
    //http://stackoverflow.com/questions/19602727/how-to-reference-javafx-fxml-files-in-resource-folder
    
    public Stage primaireStage; //private
    public BorderPane rootLayout; //private
    public Stage stage;
    
    public static AnchorPane sousScreen = new AnchorPane();
    public static AnchorPane mainScreen = new AnchorPane();
 

    /*------------------------end "gestion des scenes"------------------------*/
    
    
    
    /*----------------------------pour TableView------------------------------*/
    private ObservableList<Article> mabase = FXCollections.observableArrayList(); 
    
    public void ajouterArticle(Article n)
    //public void ajouterMatière(Article n) throws MalformedURLException
    {
        /*LocalDate date = LocalDate.now();    
        String monurl = "http://sample.com.ua";
        URL source = new URL(monurl);
        n = new Article("titre", "auteur", date, source, "contenu", true);*/
        mabase.add(n);
    }

    public ObservableList<Article> getArticleData() {
        return mabase;
    }     
    /*-------------------------end "pour TableView"---------------------------*/

  
    @Override
    public void start(Stage stage) throws Exception {
        
        this.primaireStage = stage;
        //http://docs.oracle.com/javafx/2/fxml_get_started/fxml_tutorial_intermediate.htm#CACHBAEJ 
        //stage.setTitle("MotsApp Application");        
        this.primaireStage.setTitle("MotsApp Application");  
        
        /*initMainVue();
        initSousVue(); 
        */    
        
        stage.setScene(
            createScene(
                loadMainPane()
            )
        );
        
        stage.show();
 
    }   
    
    private Pane loadMainPane() throws IOException  {
        FXMLLoader loader = new FXMLLoader();
        
        Pane mainPane = (Pane) loader.load(
            getClass().getResourceAsStream(
                VueNavigateur.ROOT_LAYOUT
            )
        );
        
        //MainController mainController = loader.getController();
        RootLayoutContrôleur mainController = loader.getController();
        
        VueNavigateur.setMainController(mainController);
        VueNavigateur.loadVista(VueNavigateur.PAGE_ACCUEIL);
        
        return mainPane;
    }
    
    private Scene createScene(Pane mainPane) {
        Scene scene = new Scene(
            mainPane
        );
        
        return scene;
    }
    
/*    
    public void initMainVue(){
        try {
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainMotsApp.class.getResource("/trial/fichiersFxml/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();

            // Show the scene containing the root layout.
            Scene scene = new Scene(rootLayout);
            stage.setScene(scene);
            stage.show();    
            //return rootLayout;
            
        } catch (IOException e) {
            e.printStackTrace();
            //return rootLayout;
        }
    }
    
 public void initSousVue(){
      try {
            // Load sousVue overview.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainMotsApp.class.getResource("/trial/fichiersFxml/PageAccueil.fxml"));
            AnchorPane sousVue = (AnchorPane) loader.load();

            // Set sousVue overview into the center of root layout.
            rootLayout.setCenter(sousVue);
        } catch (IOException e) {
            e.printStackTrace();
        }     
 } 
*/    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);        
    }
    
}
