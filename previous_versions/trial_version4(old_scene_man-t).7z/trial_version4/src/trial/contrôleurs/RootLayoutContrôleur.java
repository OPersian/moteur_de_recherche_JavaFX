package trial.contrôleurs;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import trial.InterfaceMainScreen;
import trial.MainMotsApp;
import trial.ÉcranManager;

/**
 * FXML Controller class
 *
 * @author Persianova, Golubnycha
 */
public class RootLayoutContrôleur implements Initializable, 
                                             InterfaceMainScreen {
    
    ÉcranManager myController;
    
    @Override
    public void setScreenParent(ÉcranManager screenParent){ 
        myController = screenParent; 
    } 
    
    @FXML private MenuItem menuItemPageAccueil;
    @FXML private MenuItem menuItemArticleAjoute;
    @FXML private MenuItem menuItemPhotoAjoute;
    @FXML private MenuItem menuItemOuvrir;
    @FXML private MenuItem menuItemSauvegarder;
    @FXML private MenuItem menuItemSupprimer;
    @FXML private Menu menuItemModifier;
    @FXML private Menu menuItemIndexer;
    @FXML private Menu menuItemAider;
    @FXML private TextField textFieldRechercher;
    @FXML private Button rechercherBtn;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void allerPageAccueil(ActionEvent event) {
        myController.setScreen(MainMotsApp.PAGE_ACCUEIL);
    }

    @FXML
    private void allerArticleAjoute(ActionEvent event) {
        myController.setScreen(MainMotsApp.ARTICLE_AJOUTE);
    }

    @FXML
    private void allerPhotoAjoute(ActionEvent event) {
        myController.setScreen(MainMotsApp.PHOTO_AJOUTE); 
    }

    @FXML
    private void rechercher(ActionEvent event) {
         /*myController.loadScreen(MainMotsApp.MATIÉRE_TABLEAU, 
                                MainMotsApp.MATIÉRE_TABLEAU_FXML);*/
        myController.setScreen(MainMotsApp.MATIÉRE_TABLEAU); 
    }   

}
