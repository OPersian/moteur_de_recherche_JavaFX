package trial.contrôleurs;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TitledPane;
import trial.InterfaceMainScreen;
import trial.ÉcranManager;

/**
 * FXML Controller class
 *
 * @author Persianova, Golubnycha
 */
public class PageAccueilController implements Initializable,
                                              InterfaceMainScreen {
    
    ÉcranManager myController;
    
    @Override
    public void setScreenParent(ÉcranManager screenParent){ 
        myController = screenParent; 
    } 
    
    
    @FXML private TitledPane x1;
    @FXML private TitledPane x2;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
