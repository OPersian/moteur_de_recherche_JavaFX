package trial;

import java.io.IOException;
import java.io.InputStream;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.JavaFXBuilderFactory;
//import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
//import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import trial.classesGestionContenu.Article;
//import trial.contrôleurs.*;
//import trial.classesGestionContenu.*;

/**
 *
 * @author Persianova, Golubnycha
 */

public class MainMotsApp extends Application {
    
    /*--------------------------gestion des scenes----------------------------*/    
    //http://stackoverflow.com/questions/19602727/how-to-reference-javafx-fxml-files-in-resource-folder
    
    public Stage primaireStage; //private
    public BorderPane rootLayout; //private
    public Stage stage;
    public static AnchorPane sousScreen = new AnchorPane();
    public static AnchorPane mainScreen = new AnchorPane();
 
    public static final String ROOT_LAYOUT = "/trial/contrôleurs/RootLayoutController"; 
    public static final String ROOT_LAYOUT_FXML = "/trial/fichiersFxml/RootLayout.fxml";
            
    public static final String PAGE_ACCUEIL = "/trial/contrôleurs/PageAccueilController"; 
    public static final String PAGE_ACCUEIL_FXML = "/trial/fichiersFxml/PageAccueil.fxml";
    
    public static final String PHOTO_AJOUTE = "/trial/contrôleurs/PhotoAjouteController"; 
    public static final String PHOTO_AJOUTE_FXML = "/trial/fichiersFxml/PhotoAjoute.fxml"; 
    
    public static final String ARTICLE_AJOUTE = "/trial/contrôleurs/ArticleAjouteController"; 
    public static final String ARTICLE_AJOUTE_FXML = "/trial/fichiersFxml/ArticleAjoute.fxml"; 
    
    public static final String MATIÉRE_TABLEAU = "/trial/contrôleurs/MatièreTableauController"; 
    public static final String MATIÉRE_TABLEAU_FXML = "/trial/fichiersFxml/MatièreTableau.fxml"; 

    /*------------------------end "gestion des scenes"------------------------*/
    
    
    
    /*----------------------------pour TableView------------------------------*/
    private ObservableList<Article> mabase = FXCollections.observableArrayList(); 
    
    public void ajouterArticle(Article n)
    //public void ajouterMatière(Article n) throws MalformedURLException
    {
        /*LocalDate date = LocalDate.now();    
        String monurl = "http://sample.com.ua";
        URL source = new URL(monurl);
        n = new Article("titre", "auteur", date, source, "contenu", true);*/
        mabase.add(n);
    }

    public ObservableList<Article> getArticleData() {
        return mabase;
    }     
    /*-------------------------end "pour TableView"---------------------------*/

    
    ÉcranManager mainContainer = new ÉcranManager();
    
    @Override
    public void start(Stage stage) throws Exception {
        
        this.primaireStage = stage;
        //http://docs.oracle.com/javafx/2/fxml_get_started/fxml_tutorial_intermediate.htm#CACHBAEJ 
        //stage.setTitle("MotsApp Application");        
        this.primaireStage.setTitle("MotsApp Application");  

    //http://stackoverflow.com/questions/26431840/javafx-borderpane-setcenter-replaces-entire-scene
    /*BorderPane riskAnalysis = (BorderPane) FXMLLoader.load(getClass().getResource("/trial/fichiersFxml/RootLayout.fxml"));
    AnchorPane center = (AnchorPane) FXMLLoader.load(getClass().getResource("/trial/fichiersFxml/PageAccueil.fxml"));
    riskAnalysis.setCenter(center);
    stage.getScene().setRoot(riskAnalysis);    
    stage.show();    
    */           
        /*initMainVue();
        initSousVue2(); 
        */    
        
        //it works!
        initSousVue(); //it works!          
        //Parent root = FXMLLoader.load(getClass().getResource("FXMLarticleAjoute.fxml"));
        Group root = new Group();
        root.getChildren().addAll(mainContainer);
        Scene scene = new Scene(root);        
        stage.setScene(scene);
        stage.show();
        
        
        /*
        initMainVue();
                    FXMLLoader loader = new FXMLLoader();
                    InputStream in = MainMotsApp.class.getResourceAsStream("/trial/fichiersFxml/PageAccueil.fxml");
                    loader.setBuilderFactory(new JavaFXBuilderFactory());
                    loader.setLocation(MainMotsApp.class.getResource("/trial/fichiersFxml/PageAccueil.fxml"));
                    AnchorPane page;
                    
                     try {
                         page = (AnchorPane) loader.load(in);
                         in.close();
                    rootLayout.getChildren().clear();
                    rootLayout.getChildren().add(page);

                    }  catch (IOException e) {
            e.printStackTrace();
        }
        */
    }    
    
    public void initMainVue(){
        try {
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainMotsApp.class.getResource("/trial/fichiersFxml/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();

            // Show the scene containing the root layout.
            Scene scene = new Scene(rootLayout);
            stage.setScene(scene);
            stage.show();    
            //return rootLayout;
            
        } catch (IOException e) {
            e.printStackTrace();
            //return rootLayout;
        }
    }
    
 public void initSousVue2(){
      try {
            // Load sousVue overview.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainMotsApp.class.getResource("/trial/fichiersFxml/PageAccueil.fxml"));
            AnchorPane sousVue = (AnchorPane) loader.load();

            // Set sousVue overview into the center of root layout.
            rootLayout.setCenter(sousVue);
        } catch (IOException e) {
            e.printStackTrace();
        }     
 } 
    

    public void initSousVue() throws IOException{    
    //public void initSousVue(BorderPane rootLayout){
        
        mainContainer.loadScreen(MainMotsApp.ROOT_LAYOUT, 
                                 MainMotsApp.ROOT_LAYOUT_FXML);         
        
        mainContainer.loadScreen(MainMotsApp.PAGE_ACCUEIL, 
                                 MainMotsApp.PAGE_ACCUEIL_FXML);       
        
        mainContainer.loadScreen(MainMotsApp.PHOTO_AJOUTE, 
                                 MainMotsApp.PHOTO_AJOUTE_FXML);
        
        mainContainer.loadScreen(MainMotsApp.ARTICLE_AJOUTE, 
                                 MainMotsApp.ARTICLE_AJOUTE_FXML); 
        
        mainContainer.loadScreen(MainMotsApp.MATIÉRE_TABLEAU, 
                                 MainMotsApp.MATIÉRE_TABLEAU_FXML);        

        mainContainer.setScreen(MainMotsApp.ROOT_LAYOUT);
        //mainContainer.setScreen(MainMotsApp.PAGE_ACCUEIL);
        //mainContainer.setScreen(MainMotsApp.ARTICLE_AJOUTE);
        
        
        //AnchorPane sousScreen = (AnchorPane) myLoader.load();
        // Set nameSousScreen overview into the center of root layout.
        //rootLayout.setCenter(sousScreen);
       
        //AnchorPane mainScreen = (AnchorPane) myLoader.load();
        
        //AnchorPane mainScreen = new AnchorPane();
        
        /*
        Parent rootLayout = FXMLLoader.load(MainMotsApp.class.getResource("/trial/fichiersFxml/RootLayout.fxml"));
        stage.setScene(new Scene(rootLayout));
        */
        
        //AnchorPane sousScreen = new AnchorPane();
        //rootLayout.setCenter(sousScreen);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
        
        /*java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            new Image().setVisible(true);
            }
        });*/
    }
    
}
