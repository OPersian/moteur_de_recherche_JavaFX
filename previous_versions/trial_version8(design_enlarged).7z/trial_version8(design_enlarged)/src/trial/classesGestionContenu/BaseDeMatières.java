package trial.classesGestionContenu;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.TreeSet;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Persianova, Golubnycha
 */

//class has been created to debug in console regime
public class BaseDeMatières {
    
    private TreeSet<Matière> mabase;
    //TreeSet news_item;
    public BaseDeMatières()
    {
        mabase = new TreeSet<Matière>();
    }
    
    public void ajouterMatière(Matière n)
    {
        mabase.add(n);
    }
    
    public void baseAfficher(){
        
        Iterator it = mabase.iterator();
        while (it.hasNext())
        {
            System.out.println(it.next());
        }
    }
    
}
